import { Dispatch, ReactNode, SetStateAction } from "react";

export interface LayoutProps {
  children: ReactNode;
}

export interface EmployeeDataTypes {
  // id: string;
  name: string;
}

export interface EmployeeDataContextTypes {
  employee: EmployeeDataTypes | undefined;
  setEmployeeData: Dispatch<SetStateAction<EmployeeDataTypes | undefined>>;
}
