export interface ProductProps {
  productName?: string,
  productPrice?: string | number
}