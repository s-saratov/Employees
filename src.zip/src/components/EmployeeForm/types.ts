export interface EmployeeDataTypes {
  name: string,
  // age: string,
  // job?: string
}