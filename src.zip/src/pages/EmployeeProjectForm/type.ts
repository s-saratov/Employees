export interface EmployeeFormValues {
    [key: string]: string;
}