import styled from "@emotion/styled";

export const EmployeeFormPageWrapper = styled.div`
display: flex;
align-items: center;
justify-content: center;
`

