import { useContext } from "react";
import {
  CardContainer,
  CardContent,
  InfoRow,
  Label,
  Value,
  Message,
} from "./styles";
import { EmployeeDataContext } from "components/Layout/Layout";

function EmployeeCard() {
  // Деструктуризируем объект, приходящий с помощью EmployeeDataContext
  const { employee, setEmployeeData } = useContext(EmployeeDataContext);

  return (
    <CardContainer>
      <CardContent>
        <InfoRow>
          <Label>Name:</Label>
          <Value>{employee?.name}</Value>
        </InfoRow>
        <InfoRow>
          <Label>Surname:</Label>
          <Value>{}</Value>
        </InfoRow>
        {true && (
          <InfoRow>
            <Label>Age:</Label>
            <Value>{}</Value>
          </InfoRow>
        )}
        <InfoRow>
          <Label>Job Position:</Label>
          <Value>{}</Value>
        </InfoRow>
      </CardContent>
    </CardContainer>
  );
}

export default EmployeeCard;
